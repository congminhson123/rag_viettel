import pandas as pd
from unidecode import unidecode

# print(unidecode('chào bé'))
df = pd.read_excel('chunk.xlsx', sheet_name='selected')

for i, row in df.iterrows():
    filename = unidecode(str(row['title']).replace('/', '_'))
    content=row['documents']
    with open(f'chunk_folder/{filename}', "w", encoding='UTF8') as f:
        f.write(content)
        f.close()
    