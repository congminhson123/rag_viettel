from langchain_text_splitters import RecursiveCharacterTextSplitter

text_splitter = RecursiveCharacterTextSplitter(
    separators=[
        "\n\n",
        "\n",
        "."
    ],
    # Set a really small chunk size, just to show.
    chunk_size=4096,
    chunk_overlap=500,
    length_function=len,
    is_separator_regex=False,
)

# passages = text_splitter.create_documents([documents])


from langchain_text_splitters import RecursiveCharacterTextSplitter

text_splitter_2 = RecursiveCharacterTextSplitter(chunk_size=80, chunk_overlap=20)
text_splitter_4 = RecursiveCharacterTextSplitter(chunk_size=512, chunk_overlap=50)
text_splitter_5 = RecursiveCharacterTextSplitter(chunk_size=1024, chunk_overlap=64)
text_splitter_3 = RecursiveCharacterTextSplitter(
    separators=[
        "\n\n",
        "\n-----\n",
    ],
    # Set a really small chunk size, just to show.
    chunk_size=5000,
    chunk_overlap=500,
    length_function=len,
    is_separator_regex=False,
)