import time
from sentence_transformers import CrossEncoder
model = CrossEncoder("ms-marco-MiniLM-L-12-v2", device = 'cuda')

def reranking(query, passages):
    start_time = time.time()
    model_inputs = [[query, passage] for passage in passages]
    scores = model.predict(model_inputs)
    results = [{"input": inp, "score": score} for inp, score in zip(model_inputs, scores)]
    results = sorted(results, key=lambda x: x["score"], reverse=True)
    return results

def choice_doc_reranking(query, document):
    start_time = time.time()
    model_inputs = [[query, passage] for passage in passages]
    scores = model.predict(model_inputs)
    results = [{"input": inp, "score": score} for inp, score in zip(model_inputs, scores)]
    results = sorted(results, key=lambda x: x["score"], reverse=True)
    return results