import math
from collections import Counter
import os

class BM25:
    def __init__(self, documents, k1=1.2, b=0.75):
        """
        documents: Danh sách các bài viết, mỗi bài viết là một chuỗi văn bản.
        k1: Tham số điều chỉnh độ nhạy của tf.
        b: Tham số điều chỉnh độ dài tài liệu.
        """
        self.documents = [doc.split() for doc in documents]  # Tách từng bài viết thành danh sách từ
        self.k1 = k1
        self.b = b
        self.N = len(self.documents)
        self.doc_lengths = [len(doc) for doc in self.documents]
        self.avgdl = sum(self.doc_lengths) / self.N
        self.df = Counter()
        self.idf = {}
        self._calculate_df_idf()

    def _calculate_df_idf(self):
        """Tính toán df và idf cho toàn bộ từ vựng."""
        for doc in self.documents:
            unique_terms = set(doc)
            for term in unique_terms:
                self.df[term] += 1
        
        for term, df in self.df.items():
            self.idf[term] = math.log((self.N - df + 0.5) / (df + 0.5) + 1)

    def score(self, query, doc_index):
        """
        Tính điểm BM25 cho tài liệu với truy vấn.
        query: Truy vấn (chuỗi văn bản).
        doc_index: Chỉ số của tài liệu trong danh sách `documents`.
        """
        query_terms = query.split()
        doc = self.documents[doc_index]
        doc_length = len(doc)
        doc_counter = Counter(doc)
        
        score = 0
        for term in query_terms:
            if term in self.idf:
                tf = doc_counter[term]
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (1 - self.b + self.b * (doc_length / self.avgdl))
                score += self.idf[term] * numerator / denominator
        return score

    def rank(self, query):
        """
        Xếp hạng tất cả tài liệu theo điểm BM25 với truy vấn.
        query: Truy vấn (chuỗi văn bản).
        """
        scores = [(i, self.score(query, i)) for i in range(self.N)]
        return sorted(scores, key=lambda x: x[1], reverse=True)

# filenames = os.listdir('data/rank_bm25')

# # Danh sách các bài viết
# documents = [
#     "Tôi thích học Python vì nó rất mạnh mẽ và dễ học",
#     "Python là một ngôn ngữ lập trình phổ biến trong trí tuệ nhân tạo",
#     "Lập trình rất thú vị và Python là một lựa chọn tuyệt vời",
#     "Ngôn ngữ lập trình C cũng rất mạnh mẽ nhưng khó học hơn Python",
#     "Học lập trình giúp bạn giải quyết vấn đề tốt hơn"
# ]
# for name in filenames:
#     if 'ipynb' not in name:
#         documents.append(open('data/rank_bm25/'+name, encoding='utf8').read())
# # Truy vấn
# query = "thay đổi thông tin giấy tờ"

# # Khởi tạo BM25 và xếp hạng
# bm25 = BM25(documents)
# ranked_docs = bm25.rank(query)

# # Kết quả xếp hạng
# print("Kết quả xếp hạng tài liệu:")
# for doc_index, score in ranked_docs:
#     print(f"Document {doc_index}: {documents[doc_index]} (Score: {score:.4f})")