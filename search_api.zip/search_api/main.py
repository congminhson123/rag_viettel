import chromadb
from chromadb.utils import embedding_functions
# from retrive import Retrive
import time
import json
import sys
# from sentence_transformers import CrossEncoder
import uvicorn
from sentence_transformers import SentenceTransformer
# from pyvi.ViTokenizer import tokenize
import pickle
from tqdm import tqdm 
import numpy as np
import logging
import requests
from fastapi import FastAPI
from pydantic import BaseModel
import logging
import sys
from langchain_text_splitters import RecursiveCharacterTextSplitter
import pandas as pd
# from rank_bm25 import BM25Okapi
from langchain.docstore.document import Document
from langchain_community.vectorstores import Chroma
from sentence_transformers import SentenceTransformer
from langchain_community.embeddings import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain_community.document_loaders import TextLoader
from langchain_community.document_loaders import DirectoryLoader
from build_database import query_database, query_pattern, query_database_package, query_database_vthome
from chromadb.config import Settings
from langchain_community.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from pydantic import BaseModel
from fastapi import FastAPI, Body, HTTPException
import requests
import numpy as np
from langchain.docstore.document import Document
from time import time
from langchain_community.retrievers import BM25Retriever
from langchain.retrievers import  EnsembleRetriever
# from rank_bm25 import BM25Okapi
from characterchunking import text_splitter, text_splitter_2, text_splitter_3, text_splitter_4
import os
from bm25 import BM25
from FlagEmbedding import FlagReranker
import threading
logger = logging.getLogger()
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')

stdout_handler = logging.StreamHandler(sys.stdout)
stdout_handler.setLevel(logging.DEBUG)
stdout_handler.setFormatter(formatter)

file_handler = logging.FileHandler('logs.log')
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(formatter)

logger.addHandler(stdout_handler)
embedding = SentenceTransformerEmbeddings(model_name='model/vietnam_bi_encoder')
model = SentenceTransformer('model/vietnam_bi_encoder', device="cuda")
model.to('cuda')
filenames = os.listdir('data/rank_bm25')
documents_bm25 = []
for name in filenames:
    if 'ipynb' not in name:
        documents_bm25.append(open('data/rank_bm25/'+name, encoding='utf8').read())
# Truy vấn


# Khởi tạo BM25 và xếp hạng
bm25_rerank = BM25(documents_bm25)


class Item(BaseModel):
    question: str   
    document: str = "None"
    passages: list = []
app = FastAPI()

client = chromadb.PersistentClient(path="CHROMA_DATA_10032025")
embedding_func = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="model/vietnam_bi_encoder"
        )
embedding_func_eng = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="model/all-MiniLM-L6-v2"
        )
collection_Viettel_QA = client.get_or_create_collection(name="Viettel_Service", embedding_function=embedding_func,
                        metadata={"hnsw:space": "cosine"})  
list_conllections = client.list_collections()
collection_Viettel_QA_Package = client.get_or_create_collection(name="Viettel_Package", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})
collection_pattern = client.get_or_create_collection(name="Viettel_Pattern", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})
collection_semantic_cache = client.get_or_create_collection(name="semantic_cache", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})
collection_viettel_home = client.get_or_create_collection(name="Viettel_Service_Viettel_Home", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})

model_ranker = FlagReranker("/u01/os_ai/RAG_VN/model/vi_reranker", use_fp16=True)
reranker_lock = threading.Lock()
@app.post("/retrive")
def retrive(item: Item):
    question = item.question.lower()
    logger.info(question)
    return query_database(question,collection_Viettel_QA, collection_Viettel_QA_Package)

@app.post("/retrive_viettelhome")
def retrive(item: Item):
    question = item.question.lower()
    logger.info(question)
    return query_database_vthome(question, collection_viettel_home)

@app.post("/retrive_package")
def retrive(item: Item):
    question = item.question.lower()
    logger.info(question)
    return query_database_package(question, collection_Viettel_QA_Package)

@app.post("/retrive_pattern")
def retrive(item: Item):
    question = item.question.lower()
    logger.info(question)
    return {'output': query_pattern(question,collection_pattern)}

@app.post("/searchQuestion")
def retrive(item: Item):
    question = item.question.lower()
    logger.info(question)
    return query_database(question,collection_Viettel_QA,collection_chunking)

@app.post("/reranking")
def reranking(item: Item):
    query = item.question
    passages = item.passages
    model_inputs = [[query, passage] for passage in passages]
    with reranker_lock:
        scores = model_ranker.compute_score(model_inputs)
    results = [{"input": inp, "score": score} for inp, score in zip(model_inputs, scores)]
    results = sorted(results, key=lambda x: x["score"], reverse=True)
    documents, scores = [], []
    for i in results:
        documents.append(i['input'][1])
        scores.append(int(i['score']))
    return {'output':documents, 'scores': scores}

@app.post("/choice_documents")
def choice_documents(item: Item):
    query = item.question
    documents = item.document
    passages = text_splitter_4.create_documents([documents])
    model_inputs = [[query, passage.page_content] for passage in passages if len(passage.page_content) > 10]
    with reranker_lock:
        scores = model_ranker.compute_score(model_inputs)
    results = [{"input": inp, "score": score} for inp, score in zip(model_inputs, scores)]
    results = sorted(results, key=lambda x: x["score"], reverse=True)
    documents, scores = [], []
    for i in results:
        try:
            scores.append(float(i['score']))
            documents.append(i['input'][1])
        except:
            pass
        
    return {'output':documents, 'scores': scores}


@app.post("/choice_documents_test")
def choice_documents_test(item: Item):
    query = item.question.lower()
    title = item.document.split('|||')[0]
    documents = item.document.split('|||')[1]
    print(title)
    passages = text_splitter_4.create_documents([documents])
    model_inputs = [[query, 'Nội dung về ' + title  + '\n'+ passage.page_content.lower()] for passage in passages]
    with reranker_lock:
        scores = model_ranker.compute_score(model_inputs)
    results = [{"input": inp, "score": score} for inp, score in zip(model_inputs, scores)]
    results = sorted(results, key=lambda x: x["score"], reverse=True)
    documents, scores = [], []
    for i in results:
        try:
            scores.append(float(i['score']))
            documents.append(i['input'][1])
        except:
            pass
        
    return {'output':documents, 'scores': scores}

@app.post("/chunking")
def choice_documents(item: Item):
    query = item.question
    documents = item.document
    passages = text_splitter.create_documents([documents])
    return {'output': [passage.page_content for passage in passages]}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8028, reload=False)