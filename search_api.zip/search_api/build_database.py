import chromadb
import pandas as pd
import time
from chromadb.utils import embedding_functions
from tqdm import tqdm
from characterchunking import text_splitter, text_splitter_2, text_splitter_5
import hashlib
import os
from langchain_community.document_loaders import TextLoader
# from rank_bm25 import BM25Okapi
from manager_prompt import main_content, gen_synonymous, generator_question, generator_propositions
import logging
logging.getLogger("chromadb").setLevel(logging.ERROR)


list_documents = ['tv360|tv360','scontract|scontract','vcontract|vcontract','vess|vess','CA|CA','vESS_HKD|vESS_HKD','vtracking|vtracking','chung thu so|chứng thư số','hop dong dien tu|hợp đồng điện tử','mysign|mysign','camera nd 10|CAMERA NĐ 10','vmark|vmark']
key_filter = {'cửa hàng viettel':['cửa hàng', 'viettel']}
map_filenames = {}
for i in list_documents:
    map_filenames[i.split('|')[0]] = i.split('|')[1]
package = pd.read_excel('data/pattern.xlsx', engine='openpyxl', sheet_name = 'Sheet2')['question'].to_list()
package = [i.lower() for i in package]
# Hàm tạo tên collection mới dựa trên số thứ tự
def get_collection_name(base_name, index):
    return f"{base_name}_{index}"

# Hàm thêm bản ghi vào các collection, tạo collection mới nếu cần thiết
def add_record(client, base_name, record, max_records_per_collection):
    collection_index = 0
    while True:
        collection_name = get_collection_name(base_name, collection_index)
        collection = client.get_or_create_collection(collection_name, embedding_function=embedding_func, metadata={"hnsw:space": "cosine"})
        current_count = collection.count()
        if current_count < max_records_per_collection:
            collection.upsert(
            documents = record[0],
            metadatas = record[1],
            ids = record[2]
        )
            break
        else:
            collection_index += 1

def upsert_record(client, base_name, record, max_records_per_collection):
    collection_index = 0
    while True:
        collection_name = get_collection_name(base_name, collection_index)
        collection = client.get_or_create_collection(collection_name, embedding_function=embedding_func, metadata={"hnsw:space": "cosine"})
        current_count = collection.count()
        if current_count < max_records_per_collection:
            collection.upsert(
            documents = record[0],
            metadatas = record[1],
            ids = record[2]
        )
            break
        else:
            collection_index += 1

def generate_id_from_string(input_string):
    input_bytes = input_string.encode('utf-8')
    md5_hash = hashlib.md5()
    md5_hash.update(input_bytes)
    id_hex = md5_hash.hexdigest()
    return id_hex
def check_ids_exist(collections, id):
    for collection in collections:
        results = collection.get(ids=id)
        if len(results['ids']) > 0:
            return True
    else:
        return False

    
    
def generater_sentence_by_llm(passage):
    return main_content(passage).split('\n')

def update_database_QA(client, embedding_func, reset = False):
    
    if reset:
        client.delete_collection(name='Viettel_Service') 
    collection = client.get_or_create_collection(name="Viettel_Service", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})
    data = pd.read_excel('data/question_answer.xlsx', engine='openpyxl', sheet_name = 'Sheet3')
    documents, genres, ids  = [], [], []
    t1 = time.time()
    
    for i in tqdm(range(data.shape[0])):
        question_process = data['question'][i].lower().strip().replace('?', '')
        if not check_ids_exist([collection], question_process) and question_process not in documents:
            documents.append(question_process)
            ids.append(question_process + str(i))
            a = {}
            a['documents'] = str(data['documents'][i])
            a['intent'] = str(data['intent'][i])
            genres.append(a)
    i = 0
    t1 = time.time()
    steps = 10000
    print('Tổng số bản ghi tiếng việt: '+ str(len(documents)))
    while True:
        if len(documents) == 0 :
            print('Không có bản ghi tiếng việt nào được cập nhật')
            break
        current_count = collection.count()
        print('current vietnamese count', current_count)
        print('len update----', len(documents))
        if i*steps+steps < len(documents):
            collection.upsert(
            documents = documents[i*steps:i*steps+steps],
            metadatas = genres[i*steps:i*steps+steps],
            ids = ids[i*steps:i*steps+steps])
            i = i + 1
            print('Update 10000 records')
            print(time.time() - t1)
        else:
            collection.upsert(
            documents = documents[i*steps:],
            metadatas = genres[i*steps:],
            ids = ids[i*steps:])
            break

def update_database_QA_Package(client, embedding_func, reset = False):
    
    if reset:
        client.delete_collection(name='Viettel_Package') 
    collection = client.get_or_create_collection(name="Viettel_Package", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})
    data = pd.read_excel('data/question_answer.xlsx', engine='openpyxl', sheet_name = 'Gói cước')
    documents, genres, ids  = [], [], []
    t1 = time.time()
    
    for i in tqdm(range(data.shape[0])):
        question_process = data['question'][i].lower().strip().replace('?', '')
        if not check_ids_exist([collection], question_process) and question_process not in documents:
            documents.append(question_process)
            ids.append(question_process)
            a = {}
            a['documents'] = str(data['documents'][i])
            a['intent'] = str(data['intent'][i])
            genres.append(a)
    i = 0
    t1 = time.time()
    steps = 10000
    print('Tổng số bản ghi tiếng việt: '+ str(len(documents)))
    while True:
        if len(documents) == 0 :
            print('Không có bản ghi tiếng việt nào được cập nhật')
            break
        current_count = collection.count()
        print('current vietnamese count', current_count)
        print('len update----', len(documents))
        if i*steps+steps < len(documents):
            collection.upsert(
            documents = documents[i*steps:i*steps+steps],
            metadatas = genres[i*steps:i*steps+steps],
            ids = ids[i*steps:i*steps+steps])
            i = i + 1
            print('Update 10000 records')
            print(time.time() - t1)
        else:
            collection.upsert(
            documents = documents[i*steps:],
            metadatas = genres[i*steps:],
            ids = ids[i*steps:])
            break
                
        
def update_database_pattern(client, embedding_func, reset = False):
    documents, genres  = [], []
    if reset:
        client.delete_collection(name='Viettel_Pattern') 
    collection = client.get_or_create_collection(name="Viettel_Pattern", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})
    data = pd.read_excel('data/pattern.xlsx', engine='openpyxl', sheet_name = 'Sheet7')
    filenamess = os.listdir('data/viettel')
    for i in tqdm(filenamess):
        if i in map_filenames.keys():
            documents.append(' ' + map_filenames[i].lower() + ' ')
            print('filename update---', map_filenames[i])
            a = {}
            a['documents'] = open('data/viettel/' + i, encoding = 'utf8').read()
            a['intent'] = ''
            genres.append(a)
    print(documents)
    
    t1 = time.time()
    
    for i in tqdm(range(data.shape[0])):
        documents.append(' ' + data['question'][i].lower() + ' ')
        a = {}
        a['documents'] = data['documents'][i]
        a['intent'] = ''
        genres.append(a)
    if len(documents) > 0:
        collection.add(
            documents = documents,
            metadatas = genres,
            ids = documents
        )
        print(f'Đã thêm {len(documents)} bản ghi')

        
def generator_chunking_by_llm(title, document, filenames):
    texts = text_splitter.create_documents([document])
    question, child_document, parent_document = [], [], []
    for chunk_parent in texts:
        texts_2 = text_splitter_5.create_documents([chunk_parent.page_content])
        for chunk in texts_2:
            list_question = generator_propositions("Chủ đề: {}\n".format(title) + "Nội dung chính:{}" + chunk.page_content)
            for i in list_question.split('\n'):
                if len(i) > 10:
                    print(i)
                    question.append(i)
                    child_document.append(chunk_parent.page_content)
                    for j in generator_question("Nội dung về: {}\n".format(title) + i):
                        print(j)
                        question.append(j)
                        child_document.append(chunk_parent.page_content)
    pd.DataFrame({'question': question, 'child': child_document}).to_excel('data/chunk_llm/{}.xlsx'.format(filenames))
    return question, child_document, parent_document
   
    
def delete_record_chunk_by_title(client, embedding_func, title):
    collection = client.get_or_create_collection("Viettel_Service", embedding_function=embedding_func, metadata={"hnsw:space": "cosine"})
    existing_id = collection.get(where={'intent': title})
    print(collection.count())
    collection.delete(where={'intent': title})
    print(collection.count())
    
def delete_record_chunk_byid(client, embedding_func):
    collection = client.get_or_create_collection(name="Viettel_Service", embedding_function=embedding_func,
                    metadata={"hnsw:space": "cosine"})
    print(collection.count())
    data = pd.read_excel('data/question_answer.xlsx', engine = 'openpyxl', sheet_name = 'Sheet3')
    for i in tqdm(range(data.shape[0])):
        if data['Status'][i] == 'delete': 
            print('Delete title:---', data['question'][i].lower().strip().replace('?', ''))
            collection.delete([data['question'][i].lower().strip().replace('?', '')])
    print(collection.count())
    
def delete_collection(client, collection):
    client.delete_collection(name=collection)            

            
def query_database_package(question, collection_package):
    t1 = time.time()
    results = {}
    ids, distances, metadatas, documents = [], [], [], []
    results['ids'], results['distances'], results['metadatas'], results['documents'] = [], [], [], []
    output_QA_P = collection_package.query(
            query_texts=[question],
            n_results=50,
            )
    count = 0
    for i in range(50):
        if output_QA_P['metadatas'][0][i] not in metadatas and count <= 15:
            count = count + 1
            ids.append(output_QA_P['ids'][0][i])
            distances.append(output_QA_P['distances'][0][i] - 0.05)
            metadatas.append(output_QA_P['metadatas'][0][i])
            documents.append(output_QA_P['documents'][0][i])

    for i in range(len(ids)):
        results['ids'].append(ids[i])
        results['distances'].append(distances[i])
        results['metadatas'].append(metadatas[i])
        results['documents'].append(documents[i])
    return results
    

        
def query_database(question, collection, collection_package):
    t1 = time.time()
    results = {}
    ids, distances, metadatas, documents = [], [], [], []
    results['ids'], results['distances'], results['metadatas'], results['documents'] = [], [], [], []
    output_QA = collection.query(
            query_texts=[question],
            n_results=20,
            )
    # print(output_QA)
    max_QA = len(output_QA['ids'][0])

    for i in range(max_QA):
        if output_QA['metadatas'][0][i] not in metadatas:
            ids.append(output_QA['ids'][0][i])
            distances.append(output_QA['distances'][0][i])
            metadatas.append(output_QA['metadatas'][0][i])
            documents.append(output_QA['documents'][0][i])
            
            
    output_QA_P = collection_package.query(
            query_texts=[question],
            n_results=1000
            )
    count = 0
    for i in range(1000):
        if output_QA_P['metadatas'][0][i] not in metadatas and count <= 50:
            count = count + 1
            ids.append(output_QA_P['ids'][0][i])
            distances.append(output_QA_P['distances'][0][i] - 0.05)
            metadatas.append(output_QA_P['metadatas'][0][i])
            documents.append(output_QA_P['documents'][0][i])

    for i in range(len(ids)):
        results['ids'].append(ids[i])
        results['distances'].append(distances[i])
        results['metadatas'].append(metadatas[i])
        results['documents'].append(documents[i])
    return results

def query_database_vthome(question, collection):
    t1 = time.time()
    results = {}
    ids, distances, metadatas, documents = [], [], [], []
    results['ids'], results['distances'], results['metadatas'], results['documents'] = [], [], [], []
    output_QA = collection.query(
            query_texts=[question],
            n_results=20,
            )
    for i in range(20):
        if output_QA['metadatas'][0][i] not in metadatas:
            ids.append(output_QA['ids'][0][i])
            distances.append(output_QA['distances'][0][i])
            metadatas.append(output_QA['metadatas'][0][i])
            documents.append(output_QA['documents'][0][i])
    for i in range(len(ids)):
        results['ids'].append(ids[i])
        results['distances'].append(distances[i])
        results['metadatas'].append(metadatas[i])
        results['documents'].append(documents[i])
    return results

def query_pattern(question, collection):
    patterns = collection.get()['documents']
    output = []
    question = ' ' + question.lower() + ' '
    for i in patterns:
        if i in question:
            pattern = collection.get(ids = i)['metadatas'][0]['documents']
            output.append([i, '****'+ pattern])
    return output


def build_semantic_cache(client):
    client.delete_collection(name='semantic_cache') 
    collection = client.get_or_create_collection("semantic_cache", embedding_function=embedding_func, metadata={"hnsw:space": "cosine"})
    
            

    
if __name__ == '__main__':
    client = chromadb.PersistentClient(path="CHROMA_DATA_10032025")
    embedding_func = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="model/vietnam_bi_encoder"
        )
    # from unidecode import unidecode
#     update_database_pattern(client, embedding_func, reset = True)
#     build_semantic_cache(client)
   
    # update_database_QA(client, embedding_func, reset = False)
#     update_database_QA_Package(client, embedding_func, reset = False)
    delete_record_chunk_by_title(client, embedding_func, 'Xử lý lỗi')

#     delete_collection(client, 'Viettel_Chunking_en')