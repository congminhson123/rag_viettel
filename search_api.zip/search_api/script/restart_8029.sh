#!/bin/bash

# Bước 1: Truy cập vào container "deploy_gpt" với quyền tương tác
docker exec -it deploy_gpt bash -c "
    cd ../workspace/train/hieunv/RAG_VN || { echo 'Failed to change directory to RAG_VN'; exit 1; }
    
    # Kiểm tra nếu file PID tồn tại
    if [ -f process.pid ]; then
        # Đọc PID từ file
        PID=\$(cat process.pid)
        echo 'Killing process with PID: ' \$PID
        kill \$PID
        echo 'Process killed successfully.'
        rm -f process.pid
    else
        echo 'PID file not found. Nothing to kill.'
    fi
    if [ ! -f '../llm/bin/activate' ]; then
        echo 'Environment not found at ../llm/bin/activate'
        exit 1
    fi

    source ../llm/bin/activate || { echo 'Failed to activate Python environment'; exit 1; }

    export PYTHONHOME=../llm/
    echo \$!

    echo 'Running main.py on GPU 6...'
    CUDA_VISIBLE_DEVICES=6 nohup python main_8229.py > log/output.log 2>&1 &
    sleep 30

    echo \$!
    echo \$! > process.pid
    if [ $? -eq 0 ]; then
        echo 'Script ran successfully!'
    else
        echo 'There was an error running the script!'
    fi

    if tail -n 10 output.log | grep -i 'error'; then
        echo 'Errors detected in the log file.'
    else
        echo 'No errors in the log.'
    fi
"