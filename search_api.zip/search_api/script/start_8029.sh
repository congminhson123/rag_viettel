#!/bin/bash

MAX_RETRIES=100  # Số lần thử lại tối đa
RETRY_DELAY=10  # Thời gian chờ giữa các lần thử lại (giây)

restart_process() {
    # Bước 1: Truy cập vào container "deploy_gpt" với quyền tương tác
    docker exec -i deploy_gpt bash -c "
        cd ../workspace/train/hieunv/RAG_VN || { echo 'Failed to change directory to RAG_VN'; exit 1; }
        
        # Kiểm tra nếu file PID tồn tại
        if [ -f process_8228.pid ]; then
            # Đọc PID từ file
            PID=\$(cat process_8228.pid)
            echo 'Killing process with PID: ' \$PID
            kill \$PID || echo 'Process already dead or not found'
            echo 'Process killed successfully.'
            rm -f process_8228.pid
        else
            echo 'PID file not found. Nothing to kill.'
        fi
        
        if [ ! -f '../llm/bin/activate' ]; then
            echo 'Environment not found at ../llm/bin/activate'
            exit 1
        fi

        source ../llm/bin/activate || { echo 'Failed to activate Python environment'; exit 1; }

        export PYTHONHOME=../llm/
        
        echo 'Running main.py on GPU 6...'
        CUDA_VISIBLE_DEVICES=6 nohup python main.py > log/output_8228.log 2>&1 &
        sleep 5  # Chờ một chút để process khởi động
        
        echo \$! > process_8228.pid
        echo 'New process started with PID: ' \$(cat process_8228.pid)
    "
}

check_process() {
    # Kiểm tra xem process có còn chạy không
    docker exec -i deploy_gpt bash -c "
        if [ -f ../workspace/train/hieunv/RAG_VN/process_8228.pid ]; then
            PID=\$(cat ../workspace/train/hieunv/RAG_VN/process_8228.pid)
            if ps -p \$PID > /dev/null; then
                exit 0  # Process đang chạy
            else
                exit 1  # Process đã chết
            fi
        else
            exit 1  # Không có file PID
        fi
    "
    return $?
}

# Hàm chính
main() {
    local retries=0
    
    while [ $retries -lt $MAX_RETRIES ]; do
        restart_process
        
        # Kiểm tra process định kỳ
        while true; do
            sleep 30  # Kiểm tra mỗi 30 giây
            if ! check_process; then
                echo "Process died, attempting to restart..."
                ((retries++))
                sleep $RETRY_DELAY
                break
            fi
        done
        
        if [ $retries -ge $MAX_RETRIES ]; then
            echo "Max retries ($MAX_RETRIES) reached. Giving up."
            exit 1
        fi
    done
}

# Chạy hàm chính
main