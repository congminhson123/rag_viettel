#!/bin/bash

# Bước 1: Truy cập vào container "deploy_gpt" với quyền tương tác
docker exec -it deploy_gpt bash -c "
    cd ../u01/os_ai/RAG_VN || { echo 'Failed to change directory to RAG_VN'; exit 1; }
    
    # Kiểm tra nếu file PID tồn tại
    if [ -f process_8228.pid ]; then
        # Đọc PID từ file
        PID=\$(cat process_8228.pid)
        echo 'Killing process with PID: ' \$PID
        kill \$PID
        echo 'Process killed successfully.'
        rm -f process_8228.pid
    else
        echo 'PID file not found. Nothing to kill.'
    fi
"