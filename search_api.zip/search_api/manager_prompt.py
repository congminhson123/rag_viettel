import requests, re, ast

def get_answer_llm(instruc):
    response = requests.post(
        "http://10.207.163.16:8010/v1/chat/completions",
        json={
    "model": "Llama3",
    "messages": [{"role": "system", "content": "Hãy trả lời câu hỏi sau hoàn toàn bằng tiếng Việt"}, {"role": "user", "content": instruc}],
    "stream" : False,
    "temperature": 0.5,
    "do_sample": False
}
    )
    return  response.json()['choices'][0]['message']['content']

def main_content(text):
    summarization_prompt_template = """Phân tích đoạn văn được cung cấp và chủ đề của đoạn văn hãy liệt kê tất cả các ý chính một cách chi tiết và đầy đủ:
    {}
    Với mỗi ý chính:
	1. Đảm bảo mỗi ý chính bắt buộc bao gồm đối tượng hoặc chủ thể, chủ đề của đoạn văn đó.
    2. Mỗi ý chính được viết dưới dạng 1 câu văn.
    Đầu ra dạng danh sách theo từng dòng.
   
    """.format(text)
    return get_answer_llm(summarization_prompt_template)

def gen_synonymous(sentence):
    output =  get_answer_llm('''You are a multilingual paraphrasing and synonym-generating assistant.  Given an input sentence and a language code, generate a list of synonymous sentences with different phrasing, while preserving the original meaning.  Ensure that all generated sentences are in the specified language.

Output a numbered list of synonymous sentences.  Each sentence should be a distinct rephrasing or use synonyms where appropriate.


Example:

Input Sentence: The cat sat on the mat.
Language Code: en

Output:

1. The feline perched upon the rug.
2. The cat relaxed on the mat.
3. The kitty was seated on the floor covering.


Now, provide your output for the following:

Input Sentence: {}
Language Code: {}'''.format(sentence, 'Vietnamese'))
    return output.split('\n')


def generator_question(sentence):
    prompt = '''Generate a list of questions related to the input sentence, using various interpretations and perspectives.  The questions should encourage deeper understanding and exploration of the sentence's meaning and implications.

**Input*

* **Sentence*: {}
* **Language* Vietnamese

Format Output:
- What kind of cat is it?
- Where is the mat located?
- Why did the cat sit on the mat?

Note: Max list question is 2.
Ensure the generated questions are grammatically correct and relevant to the provided sentence and language.  Use the specified language for both the questions and any explanatory text.  If the sentence is ambiguous, generate questions that explore the different possible interpretations.'''.format(sentence)
    output =  get_answer_llm(prompt)
    return output.split('\n')



def generator_propositions(document):
    system = """Please break down the following text into simple, self-contained propositions. Ensure that each proposition meets the following criteria:

    1. Express a Single Fact: Each proposition should state one specific fact or claim.
    2. Be Understandable Without Context: The proposition should be self-contained, meaning it can be understood without needing additional context.
    3. Use Full Names, Not Pronouns: Avoid pronouns or ambiguous references; use full entity names.
    4. Include Relevant Dates/Qualifiers: If applicable, include necessary dates, times, and qualifiers to make the fact precise.
    5. Contain One Subject-Predicate Relationship: Focus on a single subject and its corresponding action or attribute, without conjunctions or multiple clauses.
    6. The output format should be the same as the example below. No introduction is needed
    7. Respone only by Vietnamese.
*** Example:
Input: In 1969, Neil Armstrong became the first person to walk on the Moon during the Apollo 11 mission. 
Ouput: 
- Neil Armstrong walked on the Moon in 1969.
- Neil Armstrong was the first person to walk on the Moon.
- Neil Armstrong walked on the Moon during the Apollo 11 mission.
- The Apollo 11 mission occurred in 1969.

Documents: 
{}"""
    response = requests.post(
        "http://10.207.163.16:8010/v1/chat/completions",
        json={
    "model": "Llama3",
    "messages": [{"role": "system", "content": "Hãy phản hồi hoàn toàn bằng tiếng Việt"}, {"role": "user", "content": system.format(document)}],
    "stream" : False,
    "temperature": 0.5,
    "do_sample": False
}
    )
    return  response.json()['choices'][0]['message']['content']